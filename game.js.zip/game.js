//warning for clicking new game
function warning() {
  var answer = confirm(
    "If you click ok, you will loose your progress in this current game."
  );
  if (answer) window.location = "index.html";
  localStorage.clear();
}
//display for player chosen
function getStorage() {
  var player1 = localStorage.getItem("Player1");
  var img1 = localStorage.getItem("img1");
  document.getElementById("player1").innerHTML += `
  <h2 class="playerId">Player 1</h2>
  <h3 class="playerTitle">${player1}</h3>
  <img class="card-img-chosen" alt="picture of player 1 character" src="${img1} "</img>
  <p class="playerScore">Score: </p>
  `;
  var player2 = localStorage.getItem("Player2");
  var img2 = localStorage.getItem("img2");
  document.getElementById("player2").innerHTML += `
  <h2 class="playerId">Player 2</h2>
  <h3 class="playerTitle">${player2}</h3> 
  <img class="card-img-chosen" alt="picture of player 2 character" src="${img2} "</img>
  <p class="playerScore">Score:</p>
  `;
}
//Display for who starts
const currentPlayer2 = document.getElementById("currentPlayer2");
currentPlayer2.style.display = "none";
const currentPlayer1 = document.getElementById("currentPlayer1");
currentPlayer1.style.display = "block";

//dice
var dice = {
  sides: 6,
  roll: function () {
    var diceNumber = Math.floor(Math.random() * 6 + 1);

    return diceNumber;
  },
};

const button = document.getElementById("button");

let isGameActive = true;
var boardField = document.querySelectorAll(".game-card");

var player1Name = localStorage.getItem("Player1");
var player2Name = localStorage.getItem("Player2");

let turn = 0;
var rolledDice = 1;

//function for which player
button.addEventListener("click", function () {
  if (isGameActive) {
    dice.roll();
    if (rolledDice < 31) {
      rolledDice++;
    } else if (rolledDice === 31) {
      isGameActive = false;
      alert("game over");
    }
  }
  if (turn == 0) {
    turn = 1;
    player1();
    console.log(player2Name + "'s turn");
  } else {
    player2();
    console.log(player1Name + "'s turn");
  }
});

//Function for player 2
let scoreP1 = 0;

function player1() {
  const p1Display = document.getElementById("player1");
  let result = dice.roll();

  //Dice result pl 1
  scoreP1 = result;

  console.log("p1 dice result = " + scoreP1);
  p1Display.innerHTML += `
  <p class="playerScore">${scoreP1}</p>`;

  turn++;
  if (rolledDice >= 2) {
    p1Display.innerHTML = "";

    console.log("scoreP1 " + scoreP1);
    console.log("result p1 " + result);

    //Score display player 1
    addedScoreP1 = scoreP1 + result;
    var player1 = localStorage.getItem("Player1");
    var img1 = localStorage.getItem("img1");

    p1Display.innerHTML += `
  <h2 class="playerId">Player 1</h2>
  <h3 class="playerTitle">${player1}</h3>
  <img class="card-img-chosen" alt="picture of player 1 character" src="${img1} "</img>
  <p class="player1Score">Score: ${addedScoreP1}</p>`;

    //Display of rolled dice
    let placeholder = document.getElementById("placeholder");
    placeholder.innerHTML = "";
    placeholder.innerHTML = `<p class="placeholderText">Player 1 you rolled a ${scoreP1}</p>`;

    //Player 2's turn display
    currentPlayer2.style.display = "block";
    currentPlayer1.style.display = "none";
    turn++;
  }
}
//Function for player 2
let scoreP2 = 0;

function player2() {
  const p2Display = document.getElementById("player2");
  let result = dice.roll();
  turn = 0;

  //Dice result pl 2
  scoreP2 = result;

  console.log("p2 dice result = " + scoreP2);
  p2Display.innerHTML += `
  <p class="playerScore">${scoreP2} </p>`;

  if (rolledDice >= 2) {
    turn = 0;
    p2Display.innerHTML = "";

    console.log("result p2 " + result);
    console.log("scoreP2 " + scoreP2);

    //Score display player 2
    addedScoreP2 = scoreP2 + result;

    var player2 = localStorage.getItem("Player2");
    var img2 = localStorage.getItem("img2");

    p2Display.innerHTML += `
  <h2 class="playerId">Player 2</h2>
  <h3 class="playerTitle">${player2}</h3> 
  <img class="card-img-chosen" alt="picture of player 2 character" src="${img2} "</img>
  <p class="player2Score">Score: ${addedScoreP2}</p>`;

    //Display of rolled dice
    let placeholder = document.getElementById("placeholder");
    placeholder.innerHTML = "";
    placeholder.innerHTML = `<p class="placeholderText"> Player 2 you rolled a ${scoreP2}</p>`;

    //Player 1's turn display
    currentPlayer1.style.display = "block";
    currentPlayer2.style.display = "none";
  }
}
